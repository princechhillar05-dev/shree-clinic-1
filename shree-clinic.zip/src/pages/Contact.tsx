import { motion } from 'motion/react';
import { MapPin, Phone, Clock, HeartPulse } from 'lucide-react';

const GOOGLE_MAPS_LINK = "https://maps.google.com/?q=Shree+Clinic+Mal+godam+road+near+Vaish+Girls+School+Kath+Mandi+New+Basti+Bahadurgarh+Haryana+124507";
const PHONE_NUMBER = "+919017145806";

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

export default function Contact() {
  return (
    <>
      {/* Appointment & Contact Section */}
      <section id="contact" className="py-12 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-heading font-bold text-trust-navy">Contact & Booking</h1>
            <div className="w-24 h-1 bg-healing-teal mx-auto mt-6 rounded-full"></div>
          </div>

          <div className="bg-trust-navy rounded-3xl overflow-hidden shadow-2xl flex flex-col lg:flex-row">
            
            {/* Contact Info container */}
            <div className="lg:w-5/12 p-10 md:p-14 text-white relative">
              <div className="absolute top-0 right-0 p-12 opacity-10">
                <HeartPulse className="w-48 h-48" />
              </div>
              <motion.div 
                 initial="hidden"
                 animate="visible"
                 variants={fadeIn}
                 className="relative z-10"
              >
                <h3 className="text-3xl font-heading font-bold mb-8">Get In Touch</h3>
                
                <div className="space-y-8">
                  <div className="flex items-start gap-4">
                    <div className="bg-white/10 p-3 rounded-full shrink-0">
                      <MapPin className="w-6 h-6 text-healing-teal" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg mb-1">Location</h4>
                      <p className="text-slate-300 leading-relaxed">
                        Mal godam road, near Vaish Girls School,<br/>
                        Kath Mandi, New Basti,<br/>
                        Bahadurgarh, Haryana 124507
                      </p>
                      <a href={GOOGLE_MAPS_LINK} target="_blank" rel="noopener noreferrer" className="inline-block mt-2 text-healing-teal font-medium hover:text-white transition-colors text-sm">
                        Open in Google Maps &rarr;
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-white/10 p-3 rounded-full shrink-0">
                      <Phone className="w-6 h-6 text-healing-teal" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg mb-1">Contact</h4>
                      <p className="text-slate-300 mb-1">090171 45806</p>
                      <a href={`tel:${PHONE_NUMBER}`} className="inline-block mt-1 text-healing-teal font-medium hover:text-white transition-colors text-sm">
                        Call Now &rarr;
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-white/10 p-3 rounded-full shrink-0">
                      <Clock className="w-6 h-6 text-healing-teal" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg mb-1">Hours</h4>
                      <p className="text-slate-300 font-medium bg-healing-teal/20 text-healing-teal px-3 py-1 rounded inline-block">
                        Open 24 Hours
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Form Container */}
            <div className="lg:w-7/12 bg-slate-50 p-10 md:p-14">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h3 className="text-2xl font-heading font-bold text-trust-navy mb-2">Book an Appointment</h3>
                <p className="text-slate-600 mb-8">Fill out the form below and we will get back to you shortly.</p>
                
                <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); alert('Appointment request submitted successfully!'); }}>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-2">Full Name</label>
                      <input type="text" id="name" required className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-healing-teal focus:border-healing-teal outline-none transition-all placeholder:text-slate-400" placeholder="John Doe" />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-slate-700 mb-2">Phone Number</label>
                      <input type="tel" id="phone" required className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-healing-teal focus:border-healing-teal outline-none transition-all placeholder:text-slate-400" placeholder="+91 90171 45806" />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="service" className="block text-sm font-medium text-slate-700 mb-2">Service Needed</label>
                    <select id="service" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-healing-teal focus:border-healing-teal outline-none transition-all text-slate-600 bg-white">
                      <option>General Consultation</option>
                      <option>Fever / Viral Infection</option>
                      <option>Chronic Disease Management</option>
                      <option>Preventive Health Checkup</option>
                      <option>Other</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-2">Message (Optional)</label>
                    <textarea id="message" rows={4} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-healing-teal focus:border-healing-teal outline-none transition-all placeholder:text-slate-400 resize-none" placeholder="Briefly describe your symptoms..."></textarea>
                  </div>

                  <button type="submit" className="w-full bg-trust-navy hover:bg-trust-navy-light text-white font-medium py-4 rounded-xl transition-colors shadow-lg shadow-trust-navy/20">
                    Send Request
                  </button>
                </form>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="h-[400px] w-full bg-slate-200">
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3499.704604543666!2d76.924294!3d28.6789!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d0b000af4ed53%3A0xc0c8ffbc7efba656!2sShree%20Clinic!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin" 
          width="100%" 
          height="100%" 
          style={{ border: 0 }} 
          allowFullScreen 
          loading="lazy" 
          referrerPolicy="no-referrer-when-downgrade"
          title="Shree Clinic Location"
        ></iframe>
      </section>
    </>
  );
}
