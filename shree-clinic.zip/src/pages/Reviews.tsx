import { motion } from 'motion/react';
import { Star } from 'lucide-react';

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.2 }
  }
};

export default function Reviews() {
  return (
    <section id="reviews" className="py-12 md:py-24 bg-slate-50 min-h-[calc(100vh-200px)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={fadeIn}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-heading font-bold text-trust-navy mb-4">Patient Testimonials</h1>
          <div className="w-24 h-1 bg-healing-teal mx-auto mt-6 mb-6 rounded-full"></div>
          <p className="text-lg text-slate-600">Real feedback from patients who have experienced our care.</p>
        </motion.div>

        <motion.div 
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
          className="grid md:grid-cols-3 gap-8"
        >
          {/* Review 1 */}
          <motion.div variants={fadeIn} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 relative flex flex-col h-full">
            <div className="flex text-yellow-400 mb-4">
              {[1,2,3,4,5].map(i => <Star key={i} className="w-5 h-5 fill-current" />)}
            </div>
            <p className="text-slate-600 mb-6 italic flex-grow">"Dr. Shivam Kansal is incredibly attentive. He listens carefully to all concerns and suggests the most effective, low-cost treatments. Highly recommended for any general physician needs in Bahadurgarh."</p>
            <div className="flex items-center gap-4 mt-auto">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center font-bold text-trust-navy">M</div>
              <div>
                <h4 className="font-heading font-bold text-trust-navy">Surya Kant</h4>
                <p className="text-xs text-slate-400">Local Guide</p>
              </div>
            </div>
          </motion.div>

          {/* Review 2 */}
          <motion.div variants={fadeIn} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 flex flex-col h-full">
            <div className="flex text-yellow-400 mb-4">
              {[1,2,3,4,5].map(i => <Star key={i} className="w-5 h-5 fill-current" />)}
            </div>
            <p className="text-slate-600 mb-6 italic flex-grow">"The clinic is spotlessly clean and very welcoming. Dr. Kansal has an excellent bedside manner which puts you right at ease. Best clinic experience I've had."</p>
            <div className="flex items-center gap-4 mt-auto">
              <div className="w-10 h-10 bg-teal-100 rounded-full flex items-center justify-center font-bold text-healing-teal">S</div>
              <div>
                <h4 className="font-heading font-bold text-trust-navy">Sushant Dawar</h4>
                <p className="text-xs text-slate-400">Patient</p>
              </div>
            </div>
          </motion.div>

           {/* Review 3 */}
           <motion.div variants={fadeIn} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 flex flex-col h-full">
            <div className="flex text-yellow-400 mb-4">
              {[1,2,3,4,5].map(i => <Star key={i} className="w-5 h-5 fill-current" />)}
            </div>
            <p className="text-slate-600 mb-6 italic flex-grow">"Available 24/7 which is a lifesaver. Accurate diagnosis and he doesn't prescribe unnecessary medicines. True professional who puts patients first."</p>
            <div className="flex items-center gap-4 mt-auto">
              <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center font-bold text-indigo-700">N</div>
              <div>
                <h4 className="font-heading font-bold text-trust-navy">Nisha Harit</h4>
                <p className="text-xs text-slate-400">Patient</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
