import { motion } from 'motion/react';
import { Star, CheckCircle } from 'lucide-react';

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

export default function About() {
  return (
    <section id="about" className="py-12 md:py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-heading font-bold text-trust-navy">About Dr. Shivam Kansal</h1>
          <div className="w-24 h-1 bg-healing-teal mx-auto mt-6 rounded-full"></div>
        </div>

        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={fadeIn}
            className="lg:w-1/2 relative"
          >
            <div className="aspect-square md:aspect-[4/3] lg:aspect-square rounded-3xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=2070&auto=format&fit=crop" 
                alt="Doctor with patient" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 md:bottom-8 md:-right-8 bg-white p-6 rounded-2xl shadow-xl border border-slate-100 max-w-xs hidden sm:block">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-healing-teal/10 rounded-full flex items-center justify-center text-healing-teal">
                  <Star className="w-6 h-6 fill-current" />
                </div>
                <div>
                  <p className="font-heading font-bold text-trust-navy text-xl">5.0 Star</p>
                  <p className="text-sm text-slate-500">Google Ratings</p>
                </div>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
             initial={{ opacity: 0, x: 20 }}
             animate={{ opacity: 1, x: 0 }}
             transition={{ duration: 0.6, delay: 0.2 }}
             className="lg:w-1/2"
          >
            <h2 className="text-healing-teal font-semibold tracking-wider uppercase text-sm mb-3">Shree Clinic</h2>
            <h3 className="text-3xl md:text-4xl font-heading font-bold text-trust-navy mb-6 leading-tight">
              A Legacy of Care and Trust
            </h3>
            <div className="space-y-4 text-lg text-slate-600">
              <p>
                <strong>Dr. Shivam Kansal</strong> is a highly respected General Physician in Bahadurgarh, known for his exceptional diagnostic skills and deeply compassionate approach to patient care.
              </p>
              <p>
                With a commitment to accessible healthcare, Dr. Kansal ensures that every patient feels heard, understood, and effectively treated without unnecessary medical expenses. His excellent bedside manner has made Shree Clinic a trusted name in the community.
              </p>
              <div className="grid sm:grid-cols-2 gap-4 pt-6">
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-teal-50 p-1.5 rounded-md text-healing-teal"><CheckCircle className="w-5 h-5" /></div>
                  <span className="font-medium">Comprehensive Checkups</span>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-teal-50 p-1.5 rounded-md text-healing-teal"><CheckCircle className="w-5 h-5" /></div>
                  <span className="font-medium">Chronic Disease Management</span>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-teal-50 p-1.5 rounded-md text-healing-teal"><CheckCircle className="w-5 h-5" /></div>
                  <span className="font-medium">Fever & Viral Treatments</span>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-teal-50 p-1.5 rounded-md text-healing-teal"><CheckCircle className="w-5 h-5" /></div>
                  <span className="font-medium">Preventive Care</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
