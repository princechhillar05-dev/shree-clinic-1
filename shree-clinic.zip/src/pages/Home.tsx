import { motion } from 'motion/react';
import { MapPin, Clock, Stethoscope, UserCheck, CheckCircle, ChevronRight, Star, Users } from 'lucide-react';
import About from './About';
import Reviews from './Reviews';
import Contact from './Contact';

const GOOGLE_MAPS_LINK = "https://maps.google.com/?q=Shree+Clinic+Mal+godam+road+near+Vaish+Girls+School+Kath+Mandi+New+Basti+Bahadurgarh+Haryana+124507";

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.2 }
  }
};

export default function Home() {
  return (
    <>
      {/* Hero Section */}
      <section id="home" className="min-h-[90vh] pt-24 pb-20 md:pt-32 md:pb-28 overflow-hidden bg-gradient-to-br from-slate-50 via-white to-slate-100 flex items-center relative">
        {/* Background decorative elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
          <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] rounded-full bg-healing-teal/5 blur-[80px]"></div>
          <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] rounded-full bg-trust-navy/5 blur-[100px]"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 flex flex-col md:flex-row items-center gap-12 lg:gap-20 w-full">
          <div className="w-full md:w-1/2">
            <motion.div initial="hidden" animate="visible" variants={staggerContainer} className="flex flex-col items-start text-left">
              <motion.span variants={fadeIn} className="inline-flex items-center gap-2 px-4 py-2 bg-healing-teal/10 text-healing-teal rounded-full font-medium text-sm mb-6 border border-healing-teal/20 shadow-sm">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-healing-teal opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-healing-teal"></span>
                </span>
                Available 24/7 for Emergencies
              </motion.span>
              
              <motion.h1 variants={fadeIn} className="text-4xl md:text-5xl lg:text-7xl font-heading font-bold text-trust-navy leading-[1.1] mb-6">
                Expert Medical <br />
                Care You Can <span className="text-transparent bg-clip-text bg-gradient-to-r from-healing-teal to-teal-400">Trust.</span>
              </motion.h1>
              
              <motion.p variants={fadeIn} className="text-lg md:text-xl text-slate-600 mb-10 max-w-xl leading-relaxed">
                Led by <strong className="text-trust-navy font-semibold">Dr. Shivam Kansal</strong>, providing compassionate, personalized treatment and expert diagnosis for all your healthcare needs in Bahadurgarh.
              </motion.p>
              
              <motion.div variants={fadeIn} className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
                <a href="#contact" className="bg-trust-navy hover:bg-trust-navy-light text-white px-8 py-4 rounded-xl font-medium text-lg transition-all flex items-center justify-center gap-2 shadow-xl shadow-trust-navy/20 hover:-translate-y-1">
                  Book Appointment
                  <ChevronRight className="w-5 h-5" />
                </a>
                <a href={GOOGLE_MAPS_LINK} target="_blank" rel="noopener noreferrer" className="bg-white hover:bg-slate-50 text-trust-navy border border-slate-200 px-8 py-4 rounded-xl font-medium text-lg transition-all flex items-center justify-center gap-2 shadow-md hover:-translate-y-1">
                  <MapPin className="w-5 h-5" />
                  Get Directions
                </a>
              </motion.div>
              
              <motion.div variants={fadeIn} className="mt-10 flex items-center gap-6 text-sm text-slate-500 font-medium">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-healing-teal" />
                  <span>No hidden fees</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-healing-teal" />
                  <span>Expert Diagnosis</span>
                </div>
              </motion.div>
            </motion.div>
          </div>
          
          <div className="w-full md:w-1/2 relative mt-16 md:mt-0">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, x: 20 }} 
              animate={{ opacity: 1, scale: 1, x: 0 }} 
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="relative z-10"
            >
              {/* Main Image Container */}
              <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl shadow-trust-navy/15 border-8 border-white aspect-[4/5] object-cover bg-slate-100 z-10">
                <img 
                  src="https://images.unsplash.com/photo-1581093450021-4a7360e9a6b5?q=80&w=2070&auto=format&fit=crop" 
                  alt="Professional Doctor at Shree Clinic" 
                  className="w-full h-full object-cover object-center"
                />
                
                {/* Gradient overlay at bottom for better contrast if needed */}
                <div className="absolute inset-0 bg-gradient-to-t from-trust-navy/40 via-transparent to-transparent opacity-60"></div>
              </div>

              {/* Decorative shapes behind image */}
              <div className="absolute top-8 -right-6 w-full h-full border-2 border-healing-teal/30 rounded-[2.5rem] -z-10 transition-transform duration-500 hover:rotate-3"></div>
              
              {/* Floating Badge 1 - Happy Patients */}
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: [0, -15, 0] }}
                transition={{ 
                  opacity: { delay: 0.6, duration: 0.6 },
                  y: { repeat: Infinity, duration: 4, ease: "easeInOut", delay: 1.2 } 
                }}
                className="absolute -left-6 md:-left-12 bottom-12 bg-white p-4 rounded-2xl shadow-xl shadow-slate-200 border border-slate-100 z-20 flex items-center gap-4"
              >
                <div className="bg-blue-50 p-3 rounded-xl text-trust-navy">
                  <Users className="w-8 h-8" />
                </div>
                <div>
                  <div className="font-heading font-bold text-xl text-trust-navy">10k+</div>
                  <div className="text-xs text-slate-500 font-medium">Happy Patients</div>
                </div>
              </motion.div>

              {/* Floating Badge 2 - Ratings */}
              <motion.div 
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0, y: [0, 10, 0] }}
                transition={{ 
                  opacity: { delay: 0.8, duration: 0.6 },
                  x: { delay: 0.8, duration: 0.6 },
                  y: { repeat: Infinity, duration: 5, ease: "easeInOut", delay: 1.4 }
                }}
                className="absolute -right-4 md:-right-8 top-16 bg-white p-4 rounded-2xl shadow-xl shadow-slate-200 border border-slate-100 z-20"
              >
                <div className="flex items-center gap-2 mb-1">
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                </div>
                <div className="font-heading font-bold text-trust-navy text-lg">5.0 Star Rating</div>
                <div className="text-xs text-slate-500">Google Reviews</div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Bar */}
      <section className="-mt-16 md:-mt-24 relative z-30 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-24">
        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="bg-white rounded-2xl shadow-xl shadow-slate-200/50 p-6 md:p-8 grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8"
        >
          <motion.div variants={fadeIn} className="flex flex-col items-center text-center gap-3">
            <div className="bg-blue-50 text-trust-navy p-4 rounded-full">
              <Clock className="w-8 h-8" />
            </div>
            <h3 className="font-heading font-semibold text-trust-navy">24/7 Service</h3>
            <p className="text-sm text-slate-500">Always available for emergencies</p>
          </motion.div>
          <motion.div variants={fadeIn} className="flex flex-col items-center text-center gap-3">
            <div className="bg-teal-50 text-healing-teal p-4 rounded-full">
              <Stethoscope className="w-8 h-8" />
            </div>
            <h3 className="font-heading font-semibold text-trust-navy">Expert Diagnosis</h3>
            <p className="text-sm text-slate-500">Accurate and timely medical advice</p>
          </motion.div>
          <motion.div variants={fadeIn} className="flex flex-col items-center text-center gap-3">
            <div className="bg-blue-50 text-trust-navy p-4 rounded-full">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h3 className="font-heading font-semibold text-trust-navy">Affordable Treatment</h3>
            <p className="text-sm text-slate-500">Quality care that fits your budget</p>
          </motion.div>
          <motion.div variants={fadeIn} className="flex flex-col items-center text-center gap-3">
            <div className="bg-teal-50 text-healing-teal p-4 rounded-full">
              <UserCheck className="w-8 h-8" />
            </div>
            <h3 className="font-heading font-semibold text-trust-navy">Patient-First Care</h3>
            <p className="text-sm text-slate-500">Compassionate bedside manner</p>
          </motion.div>
        </motion.div>
      </section>

      {/* Other Sections */}
      <About />
      <Reviews />
      <Contact />
    </>
  );
}
