import { useState, useEffect, ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Phone, HeartPulse, Menu, X } from 'lucide-react';

const PHONE_NUMBER = "+919017145806";

export default function Layout({ children }: { children: ReactNode }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      const sections = ['home', 'about', 'reviews', 'contact'];
      let current = 'home';
      sections.forEach((section) => {
        const element = document.getElementById(section);
        if (element && window.scrollY >= element.offsetTop - 300) {
          current = section;
        }
      });
      setActiveSection(current);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '#home', id: 'home' },
    { name: 'About', path: '#about', id: 'about' },
    { name: 'Reviews', path: '#reviews', id: 'reviews' },
    { name: 'Contact', path: '#contact', id: 'contact' },
  ];

  return (
    <div className="min-h-screen bg-medical-white font-sans text-slate-800 flex flex-col">
      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md py-3' : 'bg-white/95 backdrop-blur-sm py-5'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <a href="#home" className="flex items-center gap-2">
              <div className="bg-healing-teal p-2 rounded-lg">
                <HeartPulse className="w-6 h-6 text-white" />
              </div>
              <span className="font-heading font-bold text-2xl text-trust-navy">Shree Clinic</span>
            </a>
            
            {/* Desktop Nav */}
            <div className="hidden md:flex items-center space-x-8">
              {navLinks.map((link) => (
                <a
                  key={link.path}
                  href={link.path}
                  className={`font-medium transition-colors ${
                    activeSection === link.id ? 'text-healing-teal' : 'text-slate-600 hover:text-healing-teal'
                  }`}
                >
                  {link.name}
                </a>
              ))}
              <a 
                href={`tel:${PHONE_NUMBER}`}
                className="bg-trust-navy text-white px-5 py-2.5 rounded-full font-medium hover:bg-trust-navy-light transition-colors flex items-center gap-2 shadow-lg shadow-trust-navy/20"
              >
                <Phone className="w-4 h-4" />
                Call Now
              </a>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-slate-600 p-2">
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-t mt-3 overflow-hidden"
            >
              <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col space-y-4">
                {navLinks.map((link) => (
                  <a
                    key={link.path}
                    href={link.path}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`font-medium ${
                      activeSection === link.id ? 'text-healing-teal' : 'text-slate-600'
                    }`}
                  >
                    {link.name}
                  </a>
                ))}
                <a 
                  href={`tel:${PHONE_NUMBER}`}
                  className="bg-healing-teal text-white px-5 py-3 rounded-lg font-medium flex items-center justify-center gap-2"
                >
                  <Phone className="w-5 h-5" />
                  Call 090171 45806
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Main Content */}
      <main className="flex-grow pt-20 md:pt-28">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-trust-navy text-slate-300 py-12 border-t border-slate-800 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <a href="#home" className="flex items-center gap-2">
              <HeartPulse className="w-6 h-6 text-healing-teal" />
              <span className="font-heading font-bold text-2xl text-white">Shree Clinic</span>
            </a>
            
            <div className="flex gap-6 text-sm font-medium">
              <a href="#home" className="hover:text-white transition-colors">Home</a>
              <a href="#about" className="hover:text-white transition-colors">About</a>
              <a href="#reviews" className="hover:text-white transition-colors">Reviews</a>
              <a href="#contact" className="hover:text-white transition-colors">Contact</a>
            </div>
          </div>
          
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-sm">
            <p>&copy; {new Date().getFullYear()} Shree Clinic - Dr. Shivam Kansal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
